Parsa Ranjbaran
501037874

Hello,

I hope you are doing great. As I completed this code, everything you asked for is correct and is running perfectly and give all the results correctly. You can find everything you asked for in the file.

Best Regards,
Parsa Ranjbaran